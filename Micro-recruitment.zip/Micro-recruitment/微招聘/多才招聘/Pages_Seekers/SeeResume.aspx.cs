﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Recruit.Models;

namespace Recruit.Pages_Seekers {
    public partial class SeeResume : System.Web.UI.Page {
        protected void Page_Load(object sender, EventArgs e) {

        }
        /// <summary>
        /// TEST
        /// </summary>
        //public IEnumerable<Recruit.Models.Resume> GetResumes() {
        //    if (Session["userid"] != null) {
        //        sid =(int) Session["userid"];
        //    }
        //    var data = new Recruit.Models.Repository.Repository_Resume().Resumes.AsQueryable<Recruit.Models.Resume>();
        //    IQueryable<Recruit.Models.Resume> resumes = data.Where(p => p.Sid == sid);
        //    return resumes;
        //    //.Where(S => S.Sid == sid);

        //    //var ss = (from r in new Recruit.Models.Repository.Repository_Resume().Resumes
        //    //          where r.Sid == sid
        //    //          orderby r.Sid
        //    //          select r);
        //}

        int sid; // 用来表示当前用户ID的  字段 。
        //**********FormView控件   启用分页时 数据绑定时，需要使用返回 IQueryable<XXXModels>类型的方法否则会抛出异常********** ,
        /// <summary>
        /// 按当前登录用户ID获取简历
        /// SelectMethod特性将其与控件关联
        /// </summary>
        /// <returns></returns>
        public IQueryable<Recruit.Models.Resume> GetResumes() {

            if (Session["userid"] != null) {
                sid = (int)Session["userid"];   //通过获取用户登录的ID,在第4X行代码...作为LINQ查询的Where 子句..
            }
            //会出现：The method 'Skip' is only supported for sorted input in LINQ to Entities. The method 'OrderBy' must be called before the method 'Skip'.

            //https://stackoverflow.com/questions/3437178/the-method-skip-is-only-supported-for-sorted-input-in-linq-to-entities
            IOrderedQueryable<Recruit.Models.Resume> resumes = new Recruit.Models.Repository.EFDbContext().Resumes.OrderBy(s => s.Rid); //按简历编号排序
            IQueryable<Recruit.Models.Resume> r = resumes.Skip(0).Where(p => p.Sid == sid);   //查询该用户ID的所有简历
            return r;
            //var data = new Recruit.Models.Repository.Repository_Resume().Resumes.AsQueryable<Recruit.Models.Resume>();
            //IQueryable<Recruit.Models.Resume> resumes = data.Where(p => p.Sid == sid);
            //return resumes;
        }



        //LINQ语法
        //var ss = (from r in new Recruit.Models.Repository.Repository_Resume().Resumes
        //          where r.Sid == sid
        //          orderby r.Sid
        //          select r);
        //public IQueryable<Recruit.Models.Resume> Resumes() {
        //    DataClasses1DataContext db = new DataClasses1DataContext();
        //    db.Lo
        //}


        public void UpdateResume(int? rid) {
            Recruit.Models.Repository.Repository_Resume repo = new Models.Repository.Repository_Resume();
            Recruit.Models.Resume resume = repo.Resumes
                .Where(p => p.Rid == rid).FirstOrDefault();     //FirstOrDefault，返回满足条件的第一个元素
            if (resume != null && TryUpdateModel<Recruit.Models.Resume>(resume)) {
                repo.SaveResume(resume);
            }
        }

        public void DeleteResume(int? rid) {
            Recruit.Models.Repository.Repository_Resume repo = new Models.Repository.Repository_Resume();
            Recruit.Models.Resume resume = repo.Resumes
                .Where(p => p.Rid == rid).FirstOrDefault();
            if (resume != null) {
                repo.DeleteResume(resume);
            }

        }

        


    }
}