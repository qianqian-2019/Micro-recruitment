﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Recruit.Pages_Seekers {
    public partial class Job_detail : System.Web.UI.Page {
        protected void Page_Load(object sender, EventArgs e) {
            //  Response.Write(string.Format("<script>alert('{0}')</script>",Session["job"]));
        }
        /// <summary>
        /// 投递简历
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Button1_Click(object sender, EventArgs e) {
            if (Session["role"] == null) {
                Response.Redirect("~/Pages/Login.aspx");
            }
            Recruit.Models.Job job = new Recruit.Models.Job();
            if (Session["job"] != null) {
                job = (Recruit.Models.Job)Session["job"];
                Recruit.Models.Company company = Recruit.Models.DCompany.GetCompanyById(job.Jid);
            }
            if (!Recruit.Models.DJob.PushResume(job.Jid, Convert.ToInt32(Session["userid"]))) {
                Response.Write("<script>alert('投递失败!');</script>");
            }
            Response.Write("<script>alert('投递成功!');</script>");
            //Response.Redirect("~/Pages_Seekers/Job.aspx");
        }
    }
}