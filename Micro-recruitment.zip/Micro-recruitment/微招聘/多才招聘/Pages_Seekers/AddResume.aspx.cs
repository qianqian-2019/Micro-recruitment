﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Recruit.Pages_Seekers {
    public partial class AddResume : System.Web.UI.Page {
        protected void Page_Load(object sender, EventArgs e) {
          
        }


        protected void btnAddResume_Click(object sender, EventArgs e) {
            Add();

        }
        /// <summary>
        /// 为当前登录的个人用户新增简历
        /// </summary>
        private void Add() {
            //为 解决 必须声明标量变量 "@XXXX"错误，没有调用 SqlDbHelper类的数据库操作方法，代码 27 -- 38，使用了AddWithValue方法代替了Add方法

            //https://bbs.csdn.net/topics/390298363
            //文档：
            //AddWithValue 将替换SqlParameterCollection.Add方法.  采用String和Object。 
            //重载Add采用一个字符串和对象已被否决，因为可能存在多义性SqlParameterCollection.Add采用重载String和一个SqlDbType可能是传递一个整数
            //，其字符串的枚举值解释为参数值或相应SqlDbType值。 使用AddWithValue每当你想要通过指定其名称和值添加参数。
            string connString = System.Configuration.ConfigurationManager.ConnectionStrings["RecruitDBConnectionString"].ConnectionString;
            SqlConnection conn = new SqlConnection(connString);
            conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = "insert into Resumes (Rname,Rsex,Rbirth,Rtel,Remail,Redu,Rworktime,Revaluate,Rproject,Rtech,Rhonor,Rhobby,Sid) values (@Rname,@Rsex,@Rbirth,@Rtel,@Remail,@Redu,@Rworktime,@Revaluate,@Rproject,@Rtech,@Rhonor,@Rhobby,@Sid)";
            //向 SqlParameterCollection 的末尾添加一个值。
            cmd.Parameters.AddWithValue("@Rname", txtName.Text.Trim());
            cmd.Parameters.AddWithValue("@Rsex", txtSex.Text.Trim());
            cmd.Parameters.AddWithValue("@Rbirth", txtBirth.Text.Trim());
            cmd.Parameters.AddWithValue("@Rtel", txtTel.Text.Trim());
            cmd.Parameters.AddWithValue("@Remail", txtemail.Text.Trim());
            cmd.Parameters.AddWithValue("@Redu", txtEdu.Text.Trim());
            cmd.Parameters.AddWithValue("@Rworktime", txtWorkTime.Text.Trim());
            cmd.Parameters.AddWithValue("@Revaluate", txtevaluate.Text.Trim());
            cmd.Parameters.AddWithValue("@Rproject", txtproject.Text.Trim());
            cmd.Parameters.AddWithValue("@Rtech", txttech.Text.Trim());
            cmd.Parameters.AddWithValue("@Rhonor", txthornor.Text.Trim());
            cmd.Parameters.AddWithValue("@Rhobby", txthobby.Text.Trim());
            //string Sid = null;  //
            //if ( Request.Form["Sid"] != null) 为了避免  “状态丢失”,（Session为 null）时报错
            //     Sid = Request.Form["Sid"]?.ToString();
            //}
            cmd.Parameters.AddWithValue("@Sid", Convert.ToInt32(Request.Form["Sid"]));//C# 可空类型（Nullable）

            if (cmd.ExecuteNonQuery() > 0) {
                Response.Write("<script>alert('添加成功!');</script>");

                DoSet();//清空文本框
                conn.Close();
            } else {
                Response.Write("<script>alert('添加失败!');</script>");
            }


        }
        /// <summary>
        /// 清空文本框
        /// </summary>
        private void DoSet() {
            txtName.Text = "";
            txtSex.Text = "";
            txtBirth.Text = "";
            txtTel.Text = "";
            txtemail.Text = "";
            txtEdu.Text = "";
            txtWorkTime.Text = "";
            txtevaluate.Text = "";
            txtproject.Text = "";
            txttech.Text = "";
            txthornor.Text = "";
            txthobby.Text = "";
        }
    }
}