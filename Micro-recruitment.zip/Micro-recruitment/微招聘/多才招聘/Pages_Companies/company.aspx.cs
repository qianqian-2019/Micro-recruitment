﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Recruit.Pages_Companies {
    public partial class company : System.Web.UI.Page {
        Recruit.Models.Company comp;
        protected void Page_Load(object sender, EventArgs e) {
            if (Session["user"] != null) {  //如果....登录用户的Session对象不为空,能跳转到这个页面的代表就是企业用户了...
                comp = (Recruit.Models.Company)Session["user"];
            } else {
                Response.Write("<script>alert('请先登录!');</script>");
                Response.Redirect("~/Pages/Login.aspx", false);     //将客户端重定向到新的 URL。 指定新的 URL 并指定当前页的执行是否应终止。
                //https://docs.microsoft.com/zh-cn/dotnet/api/system.web.httpresponse.redirect?f1url=https%3A%2F%2Fmsdn.microsoft.com%2Fquery%2Fdev15.query%3FappId%3DDev15IDEF1%26l%3DEN-US%26k%3Dk(System.Web.HttpResponse.Redirect);k(TargetFrameworkMoniker-.NETFramework,Version%3Dv4.5);k(DevLang-csharp)%26rd%3Dtrue%26f%3D255%26MSPPError%3D-2147217396&view=netframework-4.7.2
            }
        }
        /// <summary>
        /// 编辑公司信息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Button1_Click(object sender, EventArgs e) {
            String s1 = Request.Form["company_info"];
            comp.Cdetails = s1;
            if (Recruit.Models.DCompany.UpdateCompany(comp)) {
                Response.Write("<script>alert('修改完成!');</script>");
            } else {
                Response.Write("<script>alert('修改失败!');</script>");
            }
        }
        /// <summary>
        /// 编辑公司地址
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Button2_Click(object sender, EventArgs e) {
            String s1 = Request.Form["company_address"];
            comp.Caddress = s1;
            if (Recruit.Models.DCompany.UpdateCompany(comp))
                Response.Write("<script>alert('修改完成!');</script>");
            else
                Response.Write("<script>alert('修改失败!');</script>");

        }

        /// <summary>
        /// 编辑公司名称
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Button3_Click(object sender, EventArgs e) {
            String s1 = Request.Form["company_name"];
            comp.Cname = s1;
            if (Recruit.Models.DCompany.UpdateCompany(comp)) {
                Response.Write("<script>alert('修改完成!');</script>");
            } else {
                Response.Write("<script>alert('修改失败!');</script>");
            }
        }
    }
}