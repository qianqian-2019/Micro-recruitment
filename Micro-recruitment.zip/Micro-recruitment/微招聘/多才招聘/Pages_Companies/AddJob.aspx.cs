﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Recruit.Pages_Companies {
    public partial class AddJob : System.Web.UI.Page {
        Recruit.Models.Company company;
        protected void Page_Load(object sender, EventArgs e) {
            //若未登录，不能发布职位
            if (Session["user"] != null) {
                company = (Recruit.Models.Company)Session["user"];
            } else {
                Response.Write("<script>alert('请先登录!');</script>");
                Response.Redirect("~/Pages/Login.aspx", false);
            }
        }

        protected void btnAddJob_Click(object sender, EventArgs e) {
            Add();
        }

        protected void Add() {
            string connString = System.Configuration.ConfigurationManager.ConnectionStrings["RecruitDBConnectionString"].ConnectionString;
            SqlConnection conn = new SqlConnection(connString);
            conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = @"INSERT INTO [RecruitDB].[dbo].[Jobs]
           ([Jname]
           ,[Jcompany]
           ,[Jneed]
           ,[Jsalary]
           ,[Jdescription]
           ,[JRequirements]
           ,[Jdate]
           ,[JCareerCategory])
     VALUES
           (@Jname
           ,@Jcompany
           ,@Jneed
           ,@Jsalary
           ,@Jdescription
           ,@JRequirements
           ,@Jdate
           ,@JCareerCategory)";

            //向 SqlParameterCollection 的末尾添加一个值。
            cmd.Parameters.AddWithValue("@Jname", txtJname.Text.Trim());
            cmd.Parameters.AddWithValue("@Jcompany",company.Cid);
            cmd.Parameters.AddWithValue("@Jneed", txtJneed.Text.Trim());
            cmd.Parameters.AddWithValue("@Jsalary", txtJsalary.Text.Trim());
            cmd.Parameters.AddWithValue("@Jdescription", txtJdescription.Text.Trim());
            cmd.Parameters.AddWithValue("@JRequirements", txtJRequirements.Text.Trim());
            cmd.Parameters.AddWithValue("@Jdate", txtJdate.Text.Trim());
            cmd.Parameters.AddWithValue("@JCareerCategory", txtJCareerCategory.Text.Trim());

            if (cmd.ExecuteNonQuery() > 0) {
                Response.Write("<script>alert('发布职位成功!');</script>");

                DoSet();//清空文本框
                conn.Close();
            } else {
                Response.Write("<script>alert('发布失败!');</script>");
            }
        }

        private void DoSet() {
            txtJname.Text = "";
            txtJneed.Text = "";
            txtJsalary.Text = "";
            txtJdescription.Text = "";
            txtJRequirements.Text = "";
            txtJdate.Text = "";
            txtJCareerCategory.Text = "";
        }
    }
}