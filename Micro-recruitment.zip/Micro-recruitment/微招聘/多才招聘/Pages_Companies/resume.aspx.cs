﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Recruit.Pages_Companies {
    public partial class resume : System.Web.UI.Page {
        protected void Page_Load(object sender, EventArgs e) {

        }
        /// <summary>
        /// 发送面试通知
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Button1_Click(object sender, EventArgs e) {
            int Did = Convert.ToInt32(Request.QueryString["apply"]);
            if (Recruit.Models.Repository_DAL.DNews.SentNews(Did)) {
                Response.Write("<script>alert('发送通知成功!');</script>");
            }
        }

        protected void Button2_Click(object sender, EventArgs e) {

        }
    }
}