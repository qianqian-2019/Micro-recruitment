﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Recruit.Pages_Companies {
    public partial class ManaJob : System.Web.UI.Page {
        int Jcompany; //用来表示当前企业用户（公司）ID
        protected void Page_Load(object sender, EventArgs e) {

        }

        /// <summary>
        /// 使用LINQ ,枚举与查询，因为要使用分页.返回IQueryable<Job>
        /// </summary>
        /// <returns></returns>
        public IQueryable<Recruit.Models.Job> GetJobs() {
            if (Session["userid"] != null) {
                Jcompany = (int)Session["userid"];
            }
            IOrderedQueryable<Recruit.Models.Job> resumes = new Recruit.Models.Repository.EFDbContext().Jobs.OrderBy(p => p.Jid); //按工作编号排序
            IQueryable<Recruit.Models.Job> j = resumes.Skip(0).Where(p => p.Jcompany == Jcompany);   //查询该企业用户ID的所有工作
            return j;
        }

        public void UpdateJob(int? jid) {
            Recruit.Models.Repository.Repository_Job repo = new Models.Repository.Repository_Job();
            Recruit.Models.Job job = repo.Jobs
                .Where(j => j.Jid == jid).FirstOrDefault();
            if (job != null && TryUpdateModel<Recruit.Models.Job>(job)) {
                repo.SaveJob(job);
            }
        }

        public void DeleteJob(int? jid) {
            Recruit.Models.Repository.Repository_Job repo = new Models.Repository.Repository_Job();
            Recruit.Models.Job job = repo.Jobs
                .Where(j => j.Jid == jid).FirstOrDefault(); //FirstOrDefault，返回满足条件的第一个元素
            if (job != null) {    //上一行代码返回了正确的job对象
                repo.DeleteJob(job);
            }
        }
        
    }
}