﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Recruit.Pages {
    public partial class Register : System.Web.UI.Page {
        protected void Page_Load(object sender, EventArgs e) {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;

            //UserName.Text = "";
            //Email.Text = "";
            //Password.Text = "";
            //ConfirmPassword.Text = "";
        }

       
        /// <summary>
        ///注册
        /// </summary>
        private void CreateUser() {
            Recruit.Models.Seeker seeker = new Models.Seeker();
            Recruit.Models.Company company = new Models.Company();
            if (IsValid) {
                switch (identity.SelectedIndex) {   //identity为：RadioButtonList 这个控件的ID.......SelectedIndex:获取或设置列表中选定项的最低序号索引
                    case 0: //指示选中的是个人用户（默认是-1代表未选中，）
                        seeker.Susername = UserName.Text.Trim();
                        seeker.Spassword = ConfirmPassword.Text.Trim();
                        //seeker.Semail = Email.Text.Trim();
                        if (Recruit.Models.DSeeker.RegisterSeeker(seeker)) {
                            Response.Write("<script>alert('注册成功!');</script>");
                            Server.Transfer("~/Pages/Login.aspx");

                        } else {
                            Response.Write("<script>alert('注册失败，请重试!!');</script>");
                        }

                        break;
                    case 1:
                        company.Cusername = UserName.Text.Trim();
                        company.Cpassword = ConfirmPassword.Text.Trim();
                        //company.Cemail = Email.Text.Trim();
                        if (Models.DCompany.RegisterCompany(company)) {
                            Response.Write("<script>alert('注册成功!');</script>");
                            Server.Transfer("~/Pages/Login.aspx");
                        } else {
                            Response.Write("<script>alert('注册失败，请重试!!');</script>");

                        }
                        break;
                }
            }
        }

        protected void btnRegister_Click(object sender, EventArgs e) {
            CreateUser();
        }
    }
}