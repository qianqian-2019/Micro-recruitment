﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Recruit {
    public partial class Defaut : System.Web.UI.Page {
        private Recruit.Models.Repository.Repository_Job repo = new Models.Repository.Repository_Job();
        private Recruit.Models.Repository.Repository_Company repo_Company = new Models.Repository.Repository_Company();
        private int pageSize = 3;   //指定每页要显示的job数量

        public int JID;
        protected void Page_Load(object sender, EventArgs e) {
            //Session["role"] = null;
            //Session["user"] = null;
            //Session["uid"] = null;
            //Session["rid"] = null;
            //点击注销时....
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected IEnumerable<Recruit.Models.Job> GetJobs() {
            return FilterJobs()
                .OrderBy(p => p.Jid)    //OrderBy:按职位的ID排序
                .Skip((CurrentPage - 1) * pageSize) //Skip:表示从第几条数据开始，也就是说在这之前有多少条数据（每页显示为：pageSize） 
                                                    //为什么要是(CurrentPage -1  ) * pageSize  :::
                                                    //1，CurrentPage是从Request.QueryString["page"]获取的当前显示的为第几页，
                                                    //2，已知Skip()表示在这之前有多少条数据：所以，减去当前页 再乘以每页显示的数量 就是了....
                .Take(pageSize); //Take:显示多少条数据，pagesize
        }


        /// <summary>
        /// 更具Job表的公司ID（JCompany）返回对应的Company对象
        /// </summary>
        /// <param name="Cid"></param>
        /// <returns></returns>
        protected IEnumerable<Recruit.Models.Company> GetCompaniesName(int Cid) {
            return repo_Company.Companies
                .Where(p => p.Cid == Cid);
        }



        /// <summary>
        /// 判断当前所处的页面，
        /// </summary>
        protected int CurrentPage {
            get {
                //int page; //使用了输出参数。该属性返回的值
                ////return int.TryParse(Request.QueryString["page"], out page) ? page : 1;
                //page = int.TryParse(Request.QueryString["page"], out page) ? page : 1;  //可以获取page值则赋值，否则把1赋值page
                //return page > MaxPage ? MaxPage : page; //如果大于页面最大值，就返回页面最大值，否则原样返回...
                int page = GetPageFromRequest();
                return page > MaxPage ? MaxPage : page;
                //使用内置的HttpRequest对象的Request属性来查明是否有Page值属于请求URL的一部分
            }
        }

        private int GetPageFromRequest() {
            int page;
            // ??  运算符称作 null 合并运算符。 如果此运算符的左操作数不为 null，则此运算符将返回左操作数；否则返回右操作数。
            //作用 使原有的URL方案仍然有效 （CurrentPage属性内的获取page的方法
            string reqValue = (string)RouteData.Values["page"] ?? Request.QueryString["page"]; //获取路由变量
            //通过RouteData。Values集合获取路由变量
            return reqValue != null && int.TryParse(reqValue, out page) ? page : 1; //处理null值....
        }
        /// <summary>
        /// 为了避免显示空白页(请求中包括较大的Page值)，表示最大页面值，使用Count扩展方法，返回序列中的元素数， 除以每页显示 的job数(pageSize)，即得...
        /// </summary>
        protected int MaxPage {
            get {
                int jobCount = FilterJobs().Count();
                return (int)Math.Ceiling((decimal)jobCount / pageSize);
            }
        }

        /// <summary>
        /// 从路由值或查询字符串值中读取所选类别，过滤显示职位
        /// </summary>
        /// <returns></returns>
        private IEnumerable<Recruit.Models.Job> FilterJobs() {
            IEnumerable<Recruit.Models.Job> jobs = repo.Jobs;
            string currentCategory = (string)RouteData.Values["category"] ?? Request.QueryString["category"];
            //路由值或查询字符串值
            //获取路由的 url 参数值和默认值的集合
            // 包含从 url 和默认值分析的值的对象
            return currentCategory == null ? jobs : jobs.Where(p => p.JCareerCategory == currentCategory);
            //如果使用  路由值或查询字符串值 没有成功获取当前类别信息，返回默认的Product(全部返回??!!),否则返回当前选择的类别包含的job
        }
        protected void btnSearch_Click(object sender, EventArgs e) {
           // JID = int.Parse(Request.Form["push"].ToString());
        }

     
        /// <summary>
        /// 查看详情，Session或Requwest。。。。。。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDetails_Click(object sender, EventArgs e) {
            JID = int.Parse(Request.Form["push"].ToString());
          //  string jid = Request.Form["push"].ToString();
            Session["job"] = Recruit.Models.DJob.GetJobByJid(JID);
            Response.Redirect("~/Pages_Seekers/Job_detail.aspx");
        }

        protected void btnPusn_Click(object sender, EventArgs e) {
            //投递简历
        }
    }
}