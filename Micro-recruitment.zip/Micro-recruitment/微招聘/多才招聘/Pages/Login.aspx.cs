﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Recruit.Models;

namespace Recruit.Pages {
    public partial class Login : System.Web.UI.Page {
        protected void Page_Load(object sender, EventArgs e) {
            Session["role"] = null;
            Session["user"] = null;
            Session["userid"] = null;
            Session["rid"] = null;
        }

        protected void Login_Click(object sender, EventArgs e) {
            LogIn();
        }
        /// <summary>
        /// 登录
        /// </summary>
        private void LogIn() {
            if (IsValid) {
                switch (identity.SelectedIndex) {
                    case 0:
                        // test Response.Write("<script>alert('索引为 0个人用户')</script>");
                        if (Recruit.Models.DSeeker.Exist(username.Text)) {
                            Seeker seeker = Recruit.Models.DSeeker.LogIn(username.Text, Password.Text);
                            if (seeker != null) {   //如果登陆验证确认后 ，返回的用户对象
                                Session["role"] = "seeker";  //Session["role"]对象.用于识别登陆者身份（个人用户还是企业用户）,母版页SIte.Master中通过获取该Session对象实现导航到对应用户身份的“内容”
                                Session["user"] = seeker;  //Session["user"]对象 "代表" 登陆者这个对象
                                Session["userid"] = seeker.Sid;
                                Response.Write("<script>alert('登录成功!');</script>"); //为了想弹出这个对话框，使用 了Server.Transfer("url")....
                                Response.Redirect("~/Pages_Seekers/Welcome.aspx");
                                //Server.Transfer("~/Pages_Seekers/Welcome.aspx");
                                //Server的Transfer和Response的Redirect的区别，参考:
                                // http://www.cnblogs.com/sadier/articles/48299.html
                            } else {
                                Response.Write("<script>alert('密码不正确!');</script>");
                            }
                        } else {
                            Response.Write("<script>alert('用户名不存在!');</script>");
                        }
                       
                        break;
                    case 1:
                        // test Response.Write("<script>alert('索引为 0个人用户')</script>");

                        if (DCompany.Exist(username.Text)) {
                            Company company = Recruit.Models.DCompany.LogIn(username.Text, Password.Text);
                            if (company != null) {
                                Session["role"] = "company";
                                Session["user"] = company;
                                Session["userid"] = company.Cid;
                            } else {
                                Response.Write("<script>alert('密码不正确!');</script>");
                            }
                        } else {
                            Response.Write("<script>alert('用户名不存在!');</script>");
                        }
                        Session["role"] = "company";
                        Response.Write("<script>alert('登录成功');</script>");
                        Response.Redirect("~/Pages_Companies/Welcome.aspx");
                        //Server.Transfer("~/Pages_Companies/Welcome.aspx");
                        break;
                }
            }
        }
        /*
         * private void NewMethod() {
             if (IsValid) {
                 switch (identity.SelectedIndex) {
                     case 0:
                         if (DCompany.Exist(username.Text)) {
                             Company company = DCompany.Login(username.Text, Password.Text);
                             if (company != null) {
                                 Session["role"] = "company";
                                 Session["user"] = company;
                                 Session["uid"] = company.Cid;
                                 Response.Write("<script>alert('登录成功!');</script>");
                                 Server.Transfer("~/Com/welcome.aspx");
                             } else {
                                 Response.Write("<script>alert('密码不正确!');</script>");
                             }
                         } else {
                             Response.Write("<script>alert('用户名不存在!');</script>");
                         }
                         break;
                     case 1:
                         if (DSeeker.Exist(username.Text)) {
                             Seeker seeker = DSeeker.Login(username.Text, Password.Text);
                             if (seeker != null) {
                                 Session["role"] = "seeker";
                                 Session["user"] = seeker;
                                 Session["uid"] = seeker.Sid;
                                 Session["rid"] = seeker.Sresume;
                                 Response.Write("<script>alert('登录成功!');</script>");
                                 Server.Transfer("~/See/welcome.aspx");
                             } else {
                                 Response.Write("<script>alert('密码不正确!');</script>");
                             }
                         } else {
                             Response.Write("<script>alert('用户名不存在!');</script>");
                         }
                         break;
                 }
             }
         }
         * 
         * */
    }
}