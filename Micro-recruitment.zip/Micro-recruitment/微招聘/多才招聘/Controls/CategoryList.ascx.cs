﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Routing;
using System.Web.UI;
using System.Web.UI.WebControls;
using Recruit.Models.Repository;
namespace Recruit.Controls {
    public partial class CategoryList : System.Web.UI.UserControl {
        protected void Page_Load(object sender, EventArgs e) {

        }

        protected IEnumerable<string> GetCategories() {
            return new Repository_Job().Jobs
                .Select(p => p.JCareerCategory)
                .Distinct() //不重复选择
                .OrderBy(x => x);
        }

        /// <summary>
        /// 使用路由系统生成包含类别组件的URL，
        /// </summary>
        /// <param name="category"></param>
        /// <returns></returns>
        protected string CreateLinkHtml(string category) {
            string selectedCategory = (string)Page.RouteData.Values["category"] ?? Request.QueryString["category"];
            string path = RouteTable.Routes.GetVirtualPath(null, null,
                new RouteValueDictionary() { { "category", category }, { "page", "1" } }).VirtualPath;
            return string.Format("<a href='{0}' {1}>{2}</a>",
                path, category == selectedCategory ? "class='selected'" : "", category); //突出显示当前的类别（class='selected'）
            //最初的疑惑...类别信息如何获取的？？首先调用GetCategories方法返回类别信息（string）遍历返回值。。。作为该函数的参数
        }

        protected string CreateHomeLinkHtml() {
            string path = RouteTable.Routes.GetVirtualPath(null, null).VirtualPath;
            return string.Format("<a href='{0}'>最新职位</a>", path);
        }
    }
}