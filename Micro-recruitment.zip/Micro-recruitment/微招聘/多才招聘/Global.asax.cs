﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Optimization;
using System.Web.Routing;
using System.Web.Security;
using System.Web.SessionState;
using Recruit.Models.Repository;

namespace Recruit {
    public class Global : HttpApplication {
        void Application_Start(object sender, EventArgs e) {
            // Code that runs on application startup                //都是vs2017 Web Application ( ASP.NET Web Form)自动生成的代码
            RouteConfig.RegisterRoutes(RouteTable.Routes); //调用路由配置方法  vs2017 Web Application (web form)默认已添加
            BundleConfig.RegisterBundles(BundleTable.Bundles); //捆绑功能，管理js脚本和CSS文件等
            Database.SetInitializer<EFDbContext>(null);     //DbContext的数据库初始化器.使用EF时，避免后期修改数据表时会报错，
        }
    }
}