﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Recruit.Models {
    public class DSeeker {
        /// <summary>
        /// 注册个人用户
        /// </summary>
        /// <param name="seeker">seeker用户对象</param>
        /// <returns>返回bool，指示是否注册成功</returns>
        public static bool RegisterSeeker(Recruit.Models.Seeker seeker) {
            string sql = "insert into Seeker (Susername,Spassword) values (@Susername,@Spassword) ";
            List<SqlParameter> sqlParams = new List<SqlParameter>();
            sqlParams.Add(new SqlParameter("@Susername", seeker.Susername));
            sqlParams.Add(new SqlParameter("@Spassword", seeker.Spassword));
            int IsSuccces= SqlDbHelper.ExecuteNonQuery(sql, sqlParams);
            return IsSuccces > 0 ? true : false;
        }

        /// <summary>
        /// 用于判断是否存在此用户
        /// 如果存在此用户，返回true，否则返回false
        /// </summary>
        /// <param name="name"></param>
        /// <returns>如果存在此用户，返回true，否则返回false</returns>
        public static bool Exist(string username) {

            string sql = "SELECT COUNT(Sid) FROM Seeker WHERE Susername = @username";
            List<SqlParameter> sqlParameters = new List<SqlParameter> {
                new SqlParameter("@username", username)
            };
            int IsExist = Convert.ToInt32(SqlDbHelper.ExecuteScalar(sql, sqlParameters));
            return IsExist > 0 ? true : false;
        }
        public static Seeker LogIn(string username, string password) {

            //判断是否存在此用户
            if (Exist(username)) { 
                string sql = "select * from Seeker Where  Susername = @username";
                List<SqlParameter> sqlParameters = new List<SqlParameter>() {
                    new SqlParameter("@username",username)
                };
                DataTable dataTable = SqlDbHelper.GetDataTable(sql, sqlParameters);
                SqlDbHelper.SqlClose();

                //ItemArray:通过数组获取或设置此行的所有值 ，通过读取用户密码（所在的“位置”）验证此用户密码
                if (dataTable.Rows[0].ItemArray[2].ToString().Trim() == password) {
                    Seeker seeker = new Seeker {
                        Sid = (int)dataTable.Rows[0].ItemArray[0],
                        Susername = dataTable.Rows[0].ItemArray[1].ToString()
                    };      //使用对象初始化器（vs2017建议的做法，更简洁..
                    //Return 该用户。
                    return seeker;
                } else {
                    return null;
                }
            } else {
                return null;
            }
        }

    }
}