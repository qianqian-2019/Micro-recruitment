﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Recruit.Models {
    public class DCompany {
        /// <summary>
        /// 注册企业用户
        /// </summary>
        /// <param name="company">company对象</param>
        /// <returns>返回bool，指示是否注册成功</returns>
        public static bool RegisterCompany(Recruit.Models.Company company) {
            string sql = "insert into Companies (Cusername,Cpassword) values (@Cusername,@Cpassword) ";
            List<SqlParameter> sqlParams = new List<SqlParameter> {
                new SqlParameter("@Cusername", company.Cusername),
                new SqlParameter("@Cpassword", company.Cpassword),
            };
            int IsSuccces = SqlDbHelper.ExecuteNonQuery(sql, sqlParams);
            return IsSuccces > 0 ? true : false;
        }
        public static bool Exist(string username) {
            //SQL COUNT(column_name)  函数返回指定列的值的数目
            string sql = "select Count(Cid) from Companies Where Cusername=@username";
            List<SqlParameter> sqlParameters = new List<SqlParameter>() {
                new SqlParameter("@username",username)
            };
            int IsExist = Convert.ToInt32(SqlDbHelper.ExecuteScalar(sql, sqlParameters));
            SqlDbHelper.SqlClose();
            return IsExist > 0 ? true : false;
        }
        public static Company LogIn(string username,string password) {
            if (Exist(username)) {
                string sql = "select * from Companies Where Cusername=@username";
                List<SqlParameter> sqlParameters = new List<SqlParameter>() {
                    new SqlParameter("@username",username)
                };
                DataTable dataTable = SqlDbHelper.GetDataTable(sql, sqlParameters);
                SqlDbHelper.SqlClose();
                if (dataTable.Rows[0].ItemArray[4].ToString() ==password) {
                    Company company = new Company() {
                        Cid = (int)dataTable.Rows[0].ItemArray[0],
                        Cname = dataTable.Rows[0].ItemArray[1].ToString(),
                        Cdetails = dataTable.Rows[0].ItemArray[2].ToString(),
                        Caddress = dataTable.Rows[0].ItemArray[5].ToString()
                    };
                    return company;
                } else {
                    return null;
                }
            } else {
                return null;
            }
        }


        public static Company GetCompanyById(int Cid) {
            string sql = "SELECT * FROM Companies WHERE Cid = @Cid";
            List<SqlParameter> sqlParameters = new List<SqlParameter>();
            sqlParameters.Add(new SqlParameter("@CId", Cid));
            DataTable dt = SqlDbHelper.GetDataTable(sql, sqlParameters);
            SqlDbHelper.SqlClose();
            Company company = new Company();
            foreach (DataRow row in dt.Rows) {
                company.Cid = (int)row.ItemArray[0];
                company.Cname = row.ItemArray[1].ToString();
                company.Cdetails = row.ItemArray[2].ToString();
                company.Cusername = row.ItemArray[3].ToString();
                company.Caddress = row.ItemArray[5].ToString();
                company.Cemail = row.ItemArray[6].ToString();
            }
            return company;
        }

        /// <summary>
        /// 更新公司信息
        /// </summary>
        /// <param name="company"></param>
        /// <returns></returns>
        public static bool UpdateCompany(Company company) {
            string sql = "UPDATE [Companies] SET [Cname] = @Cname, [Cdetails] = @Cdetails, [Caddress] = @Caddress WHERE [Cid] = @Cid";
            List<SqlParameter> parm = new List<SqlParameter>()
                {
                    new SqlParameter("@Cname",company.Cname),
                    new SqlParameter("@Cdetails",company.Cdetails),
                    new SqlParameter("@Caddress",company.Caddress),
                    new SqlParameter("@Cid",company.Cid)
                };
            int line = SqlDbHelper.ExecuteNonQuery(sql, parm);
            SqlDbHelper.SqlClose();
            return line > 0;
        }
    }
}