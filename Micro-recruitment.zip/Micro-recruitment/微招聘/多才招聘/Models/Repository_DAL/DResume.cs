﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Recruit.Models.Repository_DAL {
    public class DResume {
        /// <summary>
        /// 新增简历(没有使用，，，在AddResume.aspx.cs里
        /// </summary>
        /// 
        /// <param name="resume">resume对象</param>
        /// <returns></returns>
        public static bool AddResume( Resume resume) {
            //string sql = "INSERT INTO Resume (Rname,Rsex,Rbirth,Rtel,Remail,Redu,Rworktime,Revaluate,Rproject,Rhonor,Rtech,Rhobby,Sid) VALUES (@Rname, @Rsex, @Rbirth, @Rtel,@Remail, @Redu, @Rworktime, @Revaluate, @Rproject, @Rhonor, @Rtech, @Rhobby, @Sid)";
            string sql = "insert into Resume (Rname,Rsex,Rbirth,Rtel,Redu,Rworktime,Revaluate,Rproject,Rtech,Rhonor,Rhobby,Sid) values (@Rname,@Rsex,@Rbirth,@Rtel,@Redu,@Rworktime,@Revaluate,@Rproject,@Rtech,@Rhonor,@Rhobby,@Sid)";
            List<SqlParameter> sqlParameters = new List<SqlParameter>() {
                new SqlParameter("@Rname",resume.Rname),
                new SqlParameter("@Rsex",resume.Rsex),
                new SqlParameter("@Rbirth",resume.Rbirth),
                new SqlParameter("@Rtel",resume.Rtel),
                new SqlParameter("@Redu",resume.Redu),
                new SqlParameter("@worktime",resume.Rworktime),
                new SqlParameter("@Revaluate",resume.Revaluate),
                new SqlParameter("@Rproject",resume.Rproject),
                new SqlParameter("@Rtech",resume.Rtech),
                new SqlParameter("@Rhonor",resume.Rhonor),
                new SqlParameter("@Rhobby",resume.Rhobby),
                new SqlParameter("@Sid",resume.Sid),
            };
            int IsSucces = SqlDbHelper.ExecuteNonQuery(sql, sqlParameters);
            return IsSucces > 0 ? true : false;

        }


        public static List<Resume> GetResumes(string Sid) {
            string sql = "select * from Resume Where Sid=@Sid";
            List<SqlParameter> sqlParameters = new List<SqlParameter>() {
                new SqlParameter("@Sid",Sid)
            };
            DataTable dt = SqlDbHelper.GetDataTable(sql, sqlParameters);
            SqlDbHelper.SqlClose();
            List<Resume> resumes = new List<Resume>();
            foreach (DataRow row in dt.Rows) {
                Resume resume = new Resume();
                resume.Rname = (string)row.ItemArray[1];
                resume.Rsex = (string)row.ItemArray[2];
                resume.Rbirth = (string)row.ItemArray[3];
                resume.Rtel = (string)row.ItemArray[4];
                resume.Remail = (string)row.ItemArray[6];
                resume.Redu = (string)row.ItemArray[7];
                resume.Rworktime = (string)row.ItemArray[8];
                resume.Revaluate = (string)row.ItemArray[9];
                resume.Rproject = (string)row.ItemArray[10];
                resume.Rtech = (string)row.ItemArray[11];
                resume.Rhonor = (string)row.ItemArray[12];
                resume.Rhobby = (string)row.ItemArray[13];

                resumes.Add(resume);

            }
            return resumes;


        }
    }
}