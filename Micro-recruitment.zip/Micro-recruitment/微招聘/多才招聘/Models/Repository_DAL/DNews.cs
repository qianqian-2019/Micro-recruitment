﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Recruit.Models.Repository_DAL {
    public class DNews {


        public static bool SentNews(int Did) {
            string sql = "INSERT INTO [News] ([Sid], [Ntitle], [Ncontent], [Ntime]) VALUES (@Sid, @Ntitle, @Ncontent, @Ntime)";
            Delivery delivery = DNews.GetDelivery(Did);
            string title = delivery.Cname + "-" + delivery.Jname + "-复试通知";
            string content = "亲爱的" + delivery.Sname + "同学:\n\t您在" + delivery.Ddatetime + "的时候向" + delivery.Cname + "公司"
                + delivery.Jname + "职位投递的简历已被提档,请等待面试通知.\n\t祝您面试顺利!";
            List<SqlParameter> parm = new List<SqlParameter>()
                {
                    new SqlParameter("@Sid",delivery.Sid),
                    new SqlParameter("@Ntitle",title),
                    new SqlParameter("@Ncontent",content),
                    new SqlParameter("@Ntime",DateTime.Now),
                };
            int line = SqlDbHelper.ExecuteNonQuery(sql, parm);
            SqlDbHelper.SqlClose();
            if (line > 0) {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 获取应聘者投递的信息
        /// </summary>
        /// <param name="Did"></param>
        /// <returns></returns>
        public static Delivery GetDelivery(int Did) {
            string sql = "SELECT Delivery.Did, jobs.Jname, companies.Cname,seeker.Sid, seeker.Susername, Delivery.Ddatetime,jobs.Jid FROM jobs INNER JOIN Delivery ON jobs.Jid = Delivery.Jid INNER JOIN seeker ON Delivery.Sid = seeker.Sid CROSS JOIN companies WHERE (Delivery.Did = @Did)";
            //SQL语句有点难，慢慢理解....
            List<SqlParameter> parm = new List<SqlParameter>()
                {
                    new SqlParameter("@Did",Did)
                };
            DataTable dt = SqlDbHelper.GetDataTable(sql, parm);
            Recruit.Models.SqlDbHelper.SqlClose();
            Delivery delivery = new Delivery();
            delivery.Did = Convert.ToInt32(dt.Rows[0].ItemArray[0]);
            delivery.Jname = dt.Rows[0].ItemArray[1].ToString();
            delivery.Cname = dt.Rows[0].ItemArray[2].ToString();
            delivery.Sid = Convert.ToInt32(dt.Rows[0].ItemArray[3]);
            delivery.Sname = dt.Rows[0].ItemArray[4].ToString();
            delivery.Ddatetime = dt.Rows[0].ItemArray[5].ToString();
            delivery.Jid = Convert.ToInt32(dt.Rows[0].ItemArray[6]);
            return delivery;
        }

        /// <summary>
        /// 根据用户ID获取信箱通知消息列表
        /// </summary>
        /// <param name="sid"></param>
        /// <returns></returns>
        public static List<News> GetNewsBySeeker(int sid) {
            string sql = "SELECT * FROM [News] WHERE ([Sid] = @Sid)";
            List<SqlParameter> parm = new List<SqlParameter>()
            {
                new SqlParameter("@Sid",sid)
            };
            DataTable dt = SqlDbHelper.GetDataTable(sql, parm);
            SqlDbHelper.SqlClose();
            List<News> newsList = new List<News>();
            foreach (DataRow row in dt.Rows) {
                News news = new News();
                news.Nid = Convert.ToInt32(row.ItemArray[0]);
                news.Ntitle = row.ItemArray[2].ToString();
                news.Ncontent = row.ItemArray[3].ToString();
                news.Ntime = row.ItemArray[4].ToString();
                newsList.Add(news);
            }
            return newsList;

        }
    }
}