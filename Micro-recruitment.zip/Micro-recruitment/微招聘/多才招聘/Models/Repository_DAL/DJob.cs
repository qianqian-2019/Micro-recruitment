﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using Recruit;

namespace Recruit.Models {
    public class DJob {
        /// <summary>
        /// 用于显示职位详情。
        /// </summary>
        /// <param name="jid"></param>
        /// <returns></returns>
        public static Job GetJobByJid(int jid) {
            string sql = "SELECT * FROM Jobs WHERE jid = @jid";
            List<SqlParameter> sqlParameters = new List<SqlParameter>();
            sqlParameters.Add(new SqlParameter("@jid", jid));
            DataTable dt = SqlDbHelper.GetDataTable(sql, sqlParameters);
            SqlDbHelper.SqlClose();
            Job job = new Job();
            foreach (DataRow row in dt.Rows) {
                job.Jid = (int)row.ItemArray[0];
                job.Jname = row.ItemArray[1].ToString();
                job.Jcompany = (int)row.ItemArray[2];
                job.Jneed = row.ItemArray[3].ToString();
                job.Jsalary = row.ItemArray[4].ToString();
                job.Jdescription = row.ItemArray[5].ToString();
                job.JRequirements = row.ItemArray[6].ToString();
                job.Jdate = row.ItemArray[7].ToString().Split(' ')[0];
                job.JCareerCategory = row.ItemArray[8].ToString();
            }
            return job;
        }


        public static bool PushResume(int jid, int sid) {
            string sql = "INSERT INTO Delivery (Jid,Sid, Ddatetime) VALUES (@Jid, @Sid, @Ddatetime)";
            List<SqlParameter>parm = new List<SqlParameter> ()
                {
                    new SqlParameter("@Jid",jid),
                    new SqlParameter("@Sid",sid),
                    new SqlParameter("@Ddatetime",DateTime.Today)
                };
            if (SqlDbHelper.ExecuteNonQuery(sql, parm) > 0) {
                SqlDbHelper.SqlClose();
                return true;
            } else {
                SqlDbHelper.SqlClose();
                return false;
            }
        }
    }
}