﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Recruit.Models {
    public class SqlDbHelper {

        static string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["RecruitDBConnectionString"].ConnectionString;
        static SqlConnection connection = new SqlConnection(ConnectionString);

        public static void SqlOpen() {
            if (connection.State != ConnectionState.Open) {
                connection.Open();
            }
        }

        /// <summary>
        /// 关闭数据库的连接
        /// </summary>
        public static void SqlClose() {
            if (connection.State == ConnectionState.Open) {
                connection.Close();
            }
        }

        public static int ExecuteNonQuery(string commandText, List<SqlParameter> sqlParameters) {
            SqlOpen();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection;
            cmd.CommandText = commandText;
            foreach (SqlParameter parameter in sqlParameters) {
                cmd.Parameters.Add(parameter);
                //cmd.Parameters.AddWithValue(parameter);
            }
            try {
                return cmd.ExecuteNonQuery();
            } catch (Exception ex) {
                throw new Exception(ex.ToString());
            }
        }
        /// <summary>
        /// 返回执行结果中首行首列的值
        /// </summary>
        /// <param name="commandText">sql查询语句</param>
        /// <param name="sqlParameters">语句参数表示 SqlCommand 的参数，或者其与 DataSet 列的映射。</param>
        /// <returns></returns>
        public static string ExecuteScalar(string commandText, List<SqlParameter> sqlParameters) {
            SqlOpen();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection;
            cmd.CommandText = commandText;
            foreach (SqlParameter parameter in sqlParameters) {
                cmd.Parameters.Add(parameter);
            }
            try {
                return cmd.ExecuteScalar().ToString();
            } catch (Exception ex) {

                throw new Exception(ex.ToString());
            }
        }
        /// <summary>
        /// 返回 ： DataSet包含的集合DataTable对象，
        /// </summary>
        /// <param name="commandText"></param>
        /// <param name="sqlParameters"></param>
        /// <returns></returns>
        public static DataSet GetDataSet(string commandText, List<SqlParameter> sqlParameters) {
            SqlOpen();
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = new SqlCommand();
            da.SelectCommand.Connection = connection;
            da.SelectCommand.CommandText = commandText;
            foreach (SqlParameter sqlParameter in sqlParameters) {
                da.SelectCommand.Parameters.Add(sqlParameter);
            }
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;
        }
        /// <summary>
        /// 返回 DataTable  内存中数据的一个表。
        /// </summary>
        /// <param name="commandText"></param>
        /// <param name="sqlParameters"></param>
        /// <returns></returns>
        public static DataTable GetDataTable(string commandText, List<SqlParameter> sqlParameters) {
            DataTable dt = new DataTable();
            dt = GetDataSet(commandText, sqlParameters).Tables[0];
            return dt;
        }
    }
}