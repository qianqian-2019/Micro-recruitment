﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Recruit.Models {
    public class Seeker {
        public int  Sid { get; set; }

        public string Susername { get; set; }

        public string Spassword { get; set; }

        public string Semail { get; set; }

        /// <summary>
        /// 重写ToString方法，用户返回用户名
        /// </summary>
        /// <returns></returns>
        public override string ToString() {
            return Susername;
        }
    }
}