﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Recruit.Models.Repository {
    public class Repository_Company {
        private EFDbContext contex = new EFDbContext();


        public IEnumerable<Company> Companies {
            get {
                return contex.Companies;
            }
        }
    }
}