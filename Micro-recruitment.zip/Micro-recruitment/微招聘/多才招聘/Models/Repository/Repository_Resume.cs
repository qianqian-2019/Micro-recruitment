﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Recruit.Models.Repository {
    /// <summary>
    /// Resume存储库
    /// </summary>
    public class Repository_Resume {
        EFDbContext context = new EFDbContext();
        public IEnumerable<Resume> Resumes {
            get {
                return context.Resumes;
            }
        }


        public void SaveResume(Resume resume) {
            if (resume.Rid == 0) {
                resume = context.Resumes.Add(resume);
            } else {
                Resume dbResume = context.Resumes.Find(resume.Rid);
                if (dbResume != null) {
                    dbResume.Rbirth = resume.Rbirth;
                    dbResume.Redu = resume.Redu;
                    dbResume.Remail = resume.Remail;
                    dbResume.Revaluate = resume.Revaluate;
                    dbResume.Rhobby = resume.Rhobby;
                    dbResume.Rhonor = resume.Rhonor;
                    dbResume.Rname = resume.Rname;
                    dbResume.Rproject = resume.Rproject;
                    dbResume.Rsex = resume.Rsex;
                    dbResume.Rtech = resume.Rtech;
                    dbResume.Rtel = resume.Rtel;
                    dbResume.Rworktime = resume.Rworktime;
                    dbResume.Sid = resume.Sid;
                }
            }
            context.SaveChanges();
        }

        public void DeleteResume(Resume resume) {
            //if (Resumes.Contains<Resume>(resume.Rid)) {
            //    context.Resumes.Remove(resume);
            //    context.SaveChanges();
            //}
            context.Resumes.Remove(resume);
            context.SaveChanges();

        }



    }
}