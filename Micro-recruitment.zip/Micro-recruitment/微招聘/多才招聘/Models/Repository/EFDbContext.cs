﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;


namespace Recruit.Models.Repository {
    /// <summary>
    /// //创建Entity Framework 上下文
    /// </summary>
    public class EFDbContext : DbContext {
       
        public DbSet<Job> Jobs { get; set; }


        public DbSet<Resume> Resumes { get; set; }

        public DbSet<Company> Companies { get; set; }

    }
}