﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Recruit.Models.Repository {
   /// <summary>
   /// Job存储库
   /// </summary>
    public class Repository_Job {
        private EFDbContext context = new EFDbContext();

        /// <summary>
        /// 返回从EFDbContext类中读取同名属性的结果
        /// 从数据库检索所有行，并使用Recruit.Models.Job对象表示每一行
        /// </summary>
        public IEnumerable<Job> Jobs {
            get {
                return context.Jobs;
            }
        }

        public void SaveJob(Job job) {
            if (job.Jid == 0) {
                job = context.Jobs.Add(job);
            } else {
                Job dbJob = context.Jobs.Find(job.Jid);
                if (dbJob != null) {
                    dbJob.Jname = job.Jname;
                    dbJob.Jcompany = job.Jcompany;
                    dbJob.Jneed = job.Jneed;
                    dbJob.Jsalary = job.Jsalary;
                    dbJob.Jdescription = job.Jdescription;
                    dbJob.JRequirements = job.JRequirements;
                    dbJob.Jdate = job.Jdate;
                    dbJob.JCareerCategory = job.JCareerCategory;
                }
            }
            context.SaveChanges();
        }

        public void DeleteJob(Job job) {
            context.Jobs.Remove(job);
            context.SaveChanges();
        }
   
        //Linq语法
        //(from student in students
        //                               where student.City == "太原"
        //                               select student.First+student.Last)
        //                       .Concat(from teacher in teachers
        //                            where teacher.City == "太原"
        //                            select teacher.First+teacher.Last);
    }
}