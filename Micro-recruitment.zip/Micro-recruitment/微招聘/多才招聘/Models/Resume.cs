﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Recruit.Models {
    public class Resume {


        //https://docs.microsoft.com/zh-cn/dotnet/api/system.web.modelbinding.formvalueprovider?view=netframework-4.7.2
        //https://docs.microsoft.com/zh-cn/dotnet/api/system.web.ui.page.modelbindingexecutioncontext?f1url=https%3A%2F%2Fmsdn.microsoft.com%2Fquery%2Fdev15.query%3FappId%3DDev15IDEF1%26l%3DEN-US%26k%3Dk(System.Web.UI.Page.ModelBindingExecutionContext);k(TargetFrameworkMoniker-.NETFramework,Version%3Dv4.5);k(DevLang-csharp)%26rd%3Dtrue&view=netframework-4.7.2
        //https://docs.microsoft.com/en-us/dotnet/api/system.web.ui.page.tryupdatemodel?f1url=https%3A%2F%2Fmsdn.microsoft.com%2Fquery%2Fdev15.query%3FappId%3DDev15IDEF1%26l%3DEN-US%26k%3Dk(System.Web.UI.Page.TryUpdateModel%60%601);k(TargetFrameworkMoniker-.NETFramework,Version%3Dv4.5);k(DevLang-csharp)%26rd%3Dtrue&view=netframework-4.7.2



        /// <summary>
        /// 简历编号
        /// </summary>
        /// 
        //https://stackoverflow.com/questions/5277788/how-to-fix-system-data-edm-edmentitytype-has-no-key
        [Key]
        public int Rid { get; set; }

        /// <summary>
        /// 姓名
        /// </summary>
        public string Rname { get; set; }
        /// <summary>
        /// 性别
        /// </summary>
        public string Rsex { get; set; }
        /// <summary>
        /// 生日
        /// </summary>
        public string Rbirth { get; set; }
        /// <summary>
        /// 联系方式
        /// </summary>
        public string Rtel { get; set; }

        //public string Rphoto { get; set; }
        /// <summary>
        /// 邮箱
        /// </summary>
        public string Remail { get; set; }
        /// <summary>
        /// 学校
        /// </summary>
        public string Redu { get; set; }
        /// <summary>
        /// 工作经历
        /// </summary>
        public string Rworktime { get; set; }
        /// <summary>
        /// 自我评价
        /// </summary>
        public string Revaluate { get; set; }
        /// <summary>
        /// 项目经验
        /// </summary>
        public string Rproject { get; set; }
        /// <summary>
        /// 教育经历
        /// </summary>
        public string Rtech { get; set; }
        /// <summary>
        /// 比赛荣誉
        /// </summary>
        public string Rhonor { get; set; }
        /// <summary>
        /// 兴趣爱好
        /// </summary>
        public string Rhobby { get; set; }

        /// <summary>
        /// 求职者ID,指示该简历属于那个用户的
        /// </summary>
        public int Sid { get; set; }
    }
}