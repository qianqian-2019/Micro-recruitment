﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Recruit.Models {
    public class Job {
        /// <summary>
        /// 职位编号
        /// </summary>
        [Key]
        public int Jid { get; set; }
        /// <summary>
        /// 职位名称
        /// </summary>
        public string Jname { get; set; }
        /// <summary>
        /// 发布公司
        /// </summary>
        public int  Jcompany { get; set; }
        /// <summary>
        /// 工作条件（XX地点/ 经验X-X年 / 大专/本科及以上 / 全职）
        /// </summary>
        public string Jneed { get; set; }
        /// <summary>
        /// 薪资待遇
        /// </summary>
        public string Jsalary { get; set; }
        /// <summary>
        /// 职位描述
        /// </summary>
        public string Jdescription { get; set; }
        /// <summary>
        /// 任职要求，
        /// </summary>
        public string JRequirements { get; set; }
        /// <summary>
        /// 发布时间
        /// </summary>
        public string Jdate { get; set; }
        /// <summary>
        /// 行业领域
        /// </summary>
        public string JCareerCategory { get; set; }
        




    }
}