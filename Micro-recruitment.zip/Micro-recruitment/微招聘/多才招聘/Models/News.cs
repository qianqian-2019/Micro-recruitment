﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Recruit.Models {
    public class News {
        public int Nid { get; set; }
        public int Sid { get; set; }

        public string Ntitle { get; set; }

        public string Ncontent { get; set; }

        public string Ntime { get; set; }
    }
}