﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Recruit.Models {
    public class Company {
        /// <summary>
        /// 公司编号
        /// </summary>

        [Key]
        public int Cid { get; set; }
        /// <summary>
        /// 公司名称
        /// </summary>
        public string Cname { get; set; }

        /// <summary>
        /// 公司简介，（信息
        /// </summary>
        public string Cdetails { get; set; }
        /// <summary>
        /// 用户名
        /// </summary>
        public string Cusername { get; set; }
        /// <summary>
        /// 密码
        /// </summary>
        public string Cpassword { get; set; }
        /// <summary>
        /// 公司地址
        /// </summary>
        public string Caddress { get; set; }
        /// <summary>
        /// 电子邮件
        /// </summary>
        public string Cemail { get; set; }


        /// <summary>
        /// 重写ToString方法，用来显示欢迎语..
        /// </summary>
        /// <returns></returns>
        public override string ToString() {
            return Cname;
        }
    }
}