﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Recruit.Models {
    public class Delivery {
        /// <summary>
        /// 投递表编号
        /// </summary>
        public int Did { get; set; }
        public int Sid { get; set; }

        public int Jid { get; set; }

        public string Ddatetime { get; set; }


        #region "额外添加的属性，用来‘灵活’ de 编写通知消息（带工作名称，应聘者名字，等...）"
        public string Jname { get; set; }
        public string Cname { get; set; }
        public string Sname { get; set; }
        #endregion



    }
}